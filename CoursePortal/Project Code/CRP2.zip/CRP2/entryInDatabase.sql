INSERT INTO `SWE`.`login` (`Swe_username`, `Swe_password`, `Swe_Category`, `Swe_PhysicallyRegistered`) VALUES 
('y09uc027', 'anshuljain', 'Student', '0'), ('y09uc086', 'mumalseth', 'Student', '0');


INSERT INTO `swe`.`coursedetails` (`SWE_CourseId`, `SWE_CourseName`, `SWE_FacultyId`, `SWE_Seats`, `SWE_Credits`, `SWE_PreRequisites`, `SWE_Type`, `SWE_Description`, `SWE_Stream_Year`) VALUES ('CN', 'Computer Networks', 'FAC001', '200', '4', 'None', 'Compulsory', '...', 'CSE_3');


INSERT INTO `SWE`.`studentdetails` (`Swe_StudentId`, `Swe_CourseId`, `Swe_Semester`) VALUES 
('y09uc027', 'CN', 'Current'),
('y09uc027', 'CN', 'Previous'),
('y09uc086', 'CN', 'Current'),
('y09uc086', 'SWE', 'Current');