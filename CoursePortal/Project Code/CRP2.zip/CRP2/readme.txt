1.import mysql jar file
2.import servlet 3.0.200901 file from tomcat lib folder