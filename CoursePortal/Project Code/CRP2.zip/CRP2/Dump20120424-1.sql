-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: courseregistrationmodule
-- ------------------------------------------------------
-- Server version	5.5.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `courseregistrationmodule`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `courseregistrationmodule` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `courseregistrationmodule`;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application` (
  `Application_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Student_ID` varchar(20) NOT NULL,
  `Application_Content` text NOT NULL,
  `Status` int(11) NOT NULL DEFAULT '0',
  `Type` varchar(20) NOT NULL,
  PRIMARY KEY (`Application_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application`
--

LOCK TABLES `application` WRITE;
/*!40000 ALTER TABLE `application` DISABLE KEYS */;
/*!40000 ALTER TABLE `application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_details`
--

DROP TABLE IF EXISTS `course_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_details` (
  `Course_ID` varchar(20) NOT NULL,
  `Course_Name` varchar(50) NOT NULL,
  `Faculty_ID` varchar(20) NOT NULL,
  `Max_seats` int(11) NOT NULL DEFAULT '10',
  `Credits` int(11) NOT NULL,
  `PreRequisites` text,
  `Course_Category` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Course_Description` text,
  `Stream` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_details`
--

LOCK TABLES `course_details` WRITE;
/*!40000 ALTER TABLE `course_details` DISABLE KEYS */;
INSERT INTO `course_details` VALUES ('ASE','Advanced Software Engineering','Fac02',10,4,'Software Engineering','Program','Elective','To make the students understand and practise the engineering principles ,and processes available in the modelling , analysis , developement , testing and maintenance of the software.','CSE'),('BC','Broadband Communication ','Fac10',10,4,'DigitalCommunication','Program ','Elective','In this elective course the student will be providede with the state of art techniques as used in the current broadband photonic networks.','ECE,CCE'),('BME','Biomedical Engineering','Fac03',20,4,'None','Science','Elective','This course tries to give the basic knowledge of Biology,BioChemistry,Human Physiology and BioMedical Engineering to the IT engineers so that they can efficiently compute to this emerging field.','CSE,CCE,ECE'),('CN','Computer Networks','Fac01',10,4,'none','Program','Compulsory','Compulsory',NULL),('COA','Computer Organisation and Architecture','Fac01',10,4,NULL,'Open','Compulsory',NULL,'CCE,CSE'),('DAA','Design and Analysis of Algorithms ','Fac19',12,4,'None','Open','Compulsory','...','CSE,CCE'),('DBMS','Database Management System','Fac18',12,4,'None','Open','Compulsory','...','CSE'),('DMS','Discrete Mathematics','Fac01',13,4,'None','Open','Compulsory','...','CSE,CCE'),('DWDM','Data Warehousing and Data Mining','Fac07',10,4,'DSA, DBMS','Program','Elective','This course will involve covering\ndata mining and knowledge discovery techniques and algorithms from the topics like Association Rule Mining , Clustering , Classification and Introduction to Data Warehousing ',NULL),('EE','Environment and Ecology','Fac11',10,4,'None','Open','Compulsory','...','CSE,ECE,CCE'),('EEM','Engineering and Electromagnetics ','Fac20',10,4,'None','Open','Compulsory','...','ECE'),('EII','ElectronicsII','Fac12',14,4,'ElectronicsI','Open','Compulsory','...','CSE,ECE,CCE'),('Eng','English','Fac14',10,5,'None','Open','Compulsory','...','CSE,ECE,CCE'),('ITW','IT Workhop','Fac04',13,3,'None','Open','Compulsory','...','CSE,ECE,CCE'),('MC','Mobile Communications','Fac06',10,4,'None','Open','Compulsory','...','ECE,CCE'),('MicroI','Microprocessors and Interfaces ','Fac21',10,4,'None','Open','Compulsory','...','ECE'),('MII','MathematicsII','Fac13',10,4,'None','Open','Compulsory','...','CSE,ECE,CCE'),('OBW','Organisational Behaviour','Fac05',10,4,'Psychology','HSS','Elective','This course will focus on understanding own behaviours as an individual and as a worker.','CSE,CCE,ECE'),('OS','Operating Systems','Fac04',14,4,'None','Open','Compulsory','...','CSE'),('PhyLab','Physics Lab','Fac15',10,2,'None','Open','Compulsory','...','CSE,ECE,CCE'),('PII','PhysicsII','Fac11',13,4,'PhysicsI','Open','Compulsory','...','CSE,ECE,CCE'),('POC','Principles of Communication','Fac17',10,4,'None','Open','Compulsory','...','ECE,CCE'),('PTSP','Probability Theory','Fac10',16,4,'None','Open','Compulsory','...','ECE,CCE'),('Signals','Signals,Systems and Control','Fac16',10,4,'None','Open','Compulsory','...','ECE,CCE'),('TCS','Topics in Computer Science ','Fac04',10,4,'None','Open ','Elective','jshgfajghua','PG'),('TOC','Theory of Computation','Fac07',10,4,'None','Open','Compulsory','...','CSE'),('VLSI','VLSI Fabrication Technology ','Fac15',15,4,'None ','Program ','Elective','An overview of the VLSI technology,brief introduction to Mos tecnology,basic circuit concepts,scaling of MOS circuits.','ECE'),('Wavelets','Introduction to Wavelets ','Fac13',15,4,'Calculus','Science ','Elective','The goal of the course is to introduce some of the basic concepts of the wave theory.','ECE,CSE,CCE');
/*!40000 ALTER TABLE `course_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_schedule`
--

DROP TABLE IF EXISTS `event_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_schedule` (
  `Event` varchar(20) NOT NULL,
  `Start_Time` datetime NOT NULL,
  `End_Time` datetime NOT NULL,
  PRIMARY KEY (`Event`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_schedule`
--

LOCK TABLES `event_schedule` WRITE;
/*!40000 ALTER TABLE `event_schedule` DISABLE KEYS */;
INSERT INTO `event_schedule` VALUES ('AddDrop','2012-04-12 10:00:00','2012-04-14 10:00:00'),('Registration','2012-04-23 22:34:29','2012-04-26 19:24:46'),('SwapDrop','2012-04-24 18:39:38','2012-04-24 19:24:41');
/*!40000 ALTER TABLE `event_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_details`
--

DROP TABLE IF EXISTS `login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_details` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Physically_Registered` varchar(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_details`
--

LOCK TABLES `login_details` WRITE;
/*!40000 ALTER TABLE `login_details` DISABLE KEYS */;
INSERT INTO `login_details` VALUES ('Dean01','123456','Dean','1'),('Fac01','123456','Faculty','1'),('Fac02','123456','Faculty','1'),('Fac03','123456','Faculty','1'),('Fac04','123456','Faculty','1'),('Fac05','123456','Faculty','1'),('Fac06','123456','Faculty','1'),('Fac07','123456','Faculty','1'),('Fac08','123456','Faculty','1'),('Fac09','123456','Faculty','1'),('Fac10','123456','Faculty','1'),('Fac11','123456','Faculty','1'),('Fac12','123456','Faculty','1'),('Fac13','123456','Faculty','1'),('Fac14','123456','Faculty','1'),('Fac15','123456','Faculty','1'),('Fac16','123456','Faculty','1'),('Fac17','123456','Faculty','1'),('Fac18','123456','Faculty','1'),('Fac19','123456','Faculty','1'),('Fac20','123456','Faculty','1'),('Fac21','123456','Faculty','1'),('Las001','123456','LAS','1'),('y08uc001','123456','Student','0'),('y08uc002','123456','Student','0'),('y08uc003','123456','Student','0'),('y08uc004','123456','Student','0'),('y08uc005','123456','Student','0'),('y08uc006','123456','Student','0'),('y08uc007','123456','Student','0'),('y08uc008','123456','Student','0'),('y08uc009','123456','Student','0'),('y08uc010','123456','Student','0'),('y08uc011','123456','Student','0'),('y08uc012','123456','Student','0'),('y08uc013','123456','Student','0'),('y08uc014','123456','Student','0'),('y08uc015','123456','Student','0'),('y09uc027','123456','Student','0'),('y09uc084','123456','Student','0'),('y09uc086','123456','Student','0'),('y09uc150','123456','Student','0'),('y09uc157','123456','Student','0'),('y09uc270','123456','Student','0'),('y09uc301','123456','Student','0'),('y10uc100','123456','Student','0'),('y10uc103','123456','Student','0'),('y10uc121','123456','Student','0'),('y10uc127','123456','Student','0'),('y10uc133','123456','Student','0'),('y11uc004','123456','Student','0'),('y11uc016','123456','Student','0'),('y11uc034','123456','Student','0'),('y11uc035','123456','Student','0'),('y11uc044','123456','Student','0'),('y11uc052','123456','Student','0'),('y11uc054','123456','Student','0');
/*!40000 ALTER TABLE `login_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_details`
--

DROP TABLE IF EXISTS `registration_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration_details` (
  `Student_ID` varchar(20) NOT NULL,
  `Course_ID` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Preference` int(11) NOT NULL DEFAULT '1',
  `Category` varchar(20) NOT NULL,
  PRIMARY KEY (`Student_ID`,`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_details`
--

LOCK TABLES `registration_details` WRITE;
/*!40000 ALTER TABLE `registration_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `registration_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_details` (
  `Student_ID` varchar(20) NOT NULL,
  `Course_ID` varchar(20) NOT NULL,
  `Semester` varchar(20) NOT NULL,
  PRIMARY KEY (`Student_ID`,`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_details`
--

LOCK TABLES `student_details` WRITE;
/*!40000 ALTER TABLE `student_details` DISABLE KEYS */;
INSERT INTO `student_details` VALUES ('y08uc001','ASD','Current'),('y08uc001','BC','Current'),('y08uc001','BioMed','Current'),('y08uc001','BSSS','Previous'),('y08uc001','CT','Previous'),('y08uc001','LA','Previous'),('y08uc001','MCA','Previous'),('y08uc001','Wavelets','Current'),('y08uc002','ASD','Current'),('y08uc002','BC','Current'),('y08uc002','BSSS','Previous'),('y08uc002','CT','Previous'),('y08uc002','DWDM','Current'),('y08uc002','EEM','Current'),('y08uc002','HV','Previous'),('y08uc002','LA','Previous'),('y08uc003','BSSS','Previous'),('y08uc003','MC','Current'),('y08uc003','MCA','Previous'),('y08uc003','OBW','Current'),('y08uc003','Optics','Previous'),('y08uc003','PA','Previous'),('y08uc003','VLSI','Current'),('y08uc003','Wavelets','Current'),('y09uc027','CN','Previous'),('y09uc027','DC','Previous'),('y09uc027','DSP','Previous'),('y09uc027','Optics','Previous'),('y09uc027','PA','Previous'),('y09uc084','ASD','Current'),('y09uc084','BioMed','Current'),('y09uc084','CN','Previous'),('y09uc084','DC','Previous'),('y09uc084','DSP','Previous'),('y09uc084','EEM','Current'),('y09uc084','MC','Current'),('y09uc084','MicroI','Current'),('y09uc084','Optics','Previous'),('y09uc084','PA','Current'),('y09uc086','CN','Previous'),('y09uc086','HV','Previous'),('y09uc086','Optics','Previous'),('y09uc086','SWE','Previous'),('y09uc086','WMKM','Previous'),('y09uc150','ASD','Current'),('y09uc150','ASE','Current'),('y09uc150','BioMed','Current'),('y09uc150','CN','Previous'),('y09uc150','DAA','Current'),('y09uc150','OBW','Current'),('y09uc150','Optics','Previous'),('y09uc150','PA','Previous'),('y09uc150','SWE','Previous'),('y09uc150','TOC','Current'),('y09uc150','WMKM','Previous'),('y09uc157','ASD','Current'),('y09uc157','BioMed','Current'),('y09uc157','EEM','Current'),('y09uc157','MC','Current'),('y09uc157','MicroI','Current'),('y09uc270','ASD','Current'),('y09uc270','BC','Current'),('y09uc270','DAA','Current'),('y09uc270','MC','Current'),('y09uc270','MicroI','Current'),('y09uc270','Wavelets','Current'),('y09uc301','CoT','Previous'),('y09uc301','DC','Previous'),('y09uc301','DSP','Previous'),('y09uc301','HV','Previous'),('y09uc301','LA','Previous'),('y10uc100','COA','Previous'),('y10uc100','DBMS','Current'),('y10uc100','DCS','Previous'),('y10uc100','DMS','Current'),('y10uc100','DSA','Previous'),('y10uc100','MIII','Previous'),('y10uc100','OBW','Current'),('y10uc100','Optics','Previous'),('y10uc100','OS','Current'),('y10uc100','PA','Previous'),('y10uc103','COA','Previous'),('y10uc103','DBMS','Current'),('y10uc103','DCS','Previous'),('y10uc103','DMS','Current'),('y10uc103','DSA','Previous'),('y10uc103','MIII','Previous'),('y10uc103','OBW','Current'),('y10uc103','Optics','Previous'),('y10uc103','OS','Current'),('y10uc103','PA','Previous'),('y10uc121','BC','Current'),('y10uc121','DCS','Previous'),('y10uc121','HV','Previous'),('y10uc121','LA','Previous'),('y10uc121','MIII','Previous'),('y10uc121','OBW','Current'),('y10uc121','POC','Current'),('y10uc121','PTSP','Current'),('y10uc121','SDC','Previous'),('y10uc121','Signals','Current'),('y10uc127','BC','Current'),('y10uc127','DCS','Previous'),('y10uc127','HV','Previous'),('y10uc127','LA','Previous'),('y10uc127','MIII','Previous'),('y10uc127','OBW','Current'),('y10uc127','POC','Current'),('y10uc127','PTSP','Current'),('y10uc127','SDC','Previous'),('y10uc127','Signals','Current'),('y10uc133','COA','Previous'),('y10uc133','DCS','Previous'),('y10uc133','DMS','Current'),('y10uc133','DSA','Previous'),('y10uc133','HV','Previous'),('y10uc133','MIII','Previous'),('y10uc133','OBW','Current'),('y10uc133','Optics','Previous'),('y10uc133','POC','Current'),('y10uc133','PTSP','Current'),('y10uc133','Signals','Current'),('y11uc004','CP','Previous'),('y11uc004','EE','Current'),('y11uc004','EI','Previous'),('y11uc004','EII','Current'),('y11uc004','Eng','Previous'),('y11uc004         ','ITW','Current'),('y11uc004','MI','Previous'),('y11uc004','MII','Current'),('y11uc004','PI','Previous'),('y11uc004','PII','Current'),('y11uc016','CP','Previous'),('y11uc016','EE','Current'),('y11uc016','EI','Previous'),('y11uc016','EII','Current'),('y11uc016','Eng','Previous'),('y11uc016','ITW','Current'),('y11uc016','MI','Previous'),('y11uc016','MII','Current'),('y11uc016','PI','Previous'),('y11uc016','PII','Current'),('y11uc034','CP','Previous'),('y11uc034','EE','Current'),('y11uc034','EI','Previous'),('y11uc034','EII','Current'),('y11uc034','Eng','Previous'),('y11uc034','ITW','Current'),('y11uc034','MI','Previous'),('y11uc034','MII','Current'),('y11uc034','PI','Previous'),('y11uc034','PII','Current'),('y11uc035','CP','Previous'),('y11uc035','EE','Current'),('y11uc035','EI','Previous'),('y11uc035','EII','Current'),('y11uc035','Eng','Previous'),('y11uc035','ITW','Current'),('y11uc035','MI','Previous'),('y11uc035','MII','Current'),('y11uc035','PI','Previous'),('y11uc035','PII','Current'),('y11uc044','CP','Previous'),('y11uc044','EE','Current'),('y11uc044','EI','Previous'),('y11uc044','EII','Current'),('y11uc044','Eng','Previous'),('y11uc044','ITW','Current'),('y11uc044','MI','Previous'),('y11uc044','MII','Current'),('y11uc044','PI','Previous'),('y11uc044','PII','Current'),('y11uc052','CP','Previous'),('y11uc052','EE','Current'),('y11uc052','EI','Previous'),('y11uc052','EII','Current'),('y11uc052','Eng','Previous'),('y11uc052','ITW','Current'),('y11uc052','MI','Previous'),('y11uc052','MII','Current'),('y11uc052','PI','Previous'),('y11uc052','PII','Current'),('y11uc054','CP','Previous'),('y11uc054','EE','Current'),('y11uc054','EI','Previous'),('y11uc054','EII','Current'),('y11uc054','Eng','Previous'),('y11uc054','ITW','Current'),('y11uc054','MI','Previous'),('y11uc054','MII','Current'),('y11uc054','PI','Previous'),('y11uc054','PII','Current');
/*!40000 ALTER TABLE `student_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `swap_course`
--

DROP TABLE IF EXISTS `swap_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `swap_course` (
  `Student_ID1` varchar(20) NOT NULL,
  `Student_ID2` varchar(20) NOT NULL,
  `Course_ID1` varchar(20) NOT NULL,
  `Course_ID2` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`Student_ID1`,`Student_ID2`,`Course_ID1`,`Course_ID2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `swap_course`
--

LOCK TABLES `swap_course` WRITE;
/*!40000 ALTER TABLE `swap_course` DISABLE KEYS */;
/*!40000 ALTER TABLE `swap_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `institutedatabase`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `institutedatabase` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `institutedatabase`;

--
-- Table structure for table `compulsory`
--

DROP TABLE IF EXISTS `compulsory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compulsory` (
  `Course_ID` varchar(20) NOT NULL DEFAULT '',
  `Branch` varchar(20) NOT NULL DEFAULT '',
  `Degree` varchar(20) NOT NULL DEFAULT '',
  `Year` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`Course_ID`,`Branch`,`Degree`,`Year`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compulsory`
--

LOCK TABLES `compulsory` WRITE;
/*!40000 ALTER TABLE `compulsory` DISABLE KEYS */;
INSERT INTO `compulsory` VALUES ('CN','CSE','B.Tech','Third'),('COA','CSE','B.Tech','Second'),('CP','CSE,ECE,CCE','B.Tech','First'),('DAA','CSE','B.Tech','Third'),('DBMS','CSE','B.Tech','Second'),('DC','ECE,CCE','B.Tech','Third'),('DCS','CSE,ECE,CCE','B.Tech','Second'),('DMS','CSE','B.Tech','Second'),('DSA','CSE','B.Tech','Second'),('DSP','ECE,CCE','B.Tech','Fourth'),('ECEIII','ECE,CCE','B.Tech','Second'),('ECELabI','CSE,ECE,CCE','B.Tech','First'),('EE','ECE,CCE','B.Tech','First'),('EEM','ECE,CCE','B.Tech','Third'),('EI','CSE,ECE,CCE','B.Tech','First'),('EII','CSE,ECE,CCE','B.Tech','First'),('Eng','CSE,ECE,CCE','B.Tech','First'),('ITW','CSE,ECE,CCE','B.Tech','First'),('MC','ECE,CCE','B.Tech','Third'),('MI','CSE,ECE,CCE','B.Tech','First'),('MicroI','ECE,CCE','B.Tech','Third'),('MII','CSE,ECE,CCE','B.Tech','First'),('MIII','CSE,ECE,CCE','B.Tech','Second'),('OS','CSE','B.Tech','Second'),('PhyLab','CSE,ECE,CCE','B.Tech','First'),('PI','CSE,ECE,CCE','B.Tech','First'),('PII','CSE,ECE,CCE','B.Tech','First'),('POC','ECE,CCE','B.Tech','Second'),('PTSP','ECE,CCE','B.Tech','Third'),('SDC','ECE,CCE','B.Tech','Second'),('Signals','ECE,CCE','B.Tech','Second'),('TOC','CSE','B.Tech','Third');
/*!40000 ALTER TABLE `compulsory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_details`
--

DROP TABLE IF EXISTS `course_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_details` (
  `Course_ID` varchar(20) NOT NULL,
  `Course_Name` varchar(50) NOT NULL,
  `Credits` int(11) NOT NULL,
  `Course_Category` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Stream` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_details`
--

LOCK TABLES `course_details` WRITE;
/*!40000 ALTER TABLE `course_details` DISABLE KEYS */;
INSERT INTO `course_details` VALUES ('ADSP','Advanced Digital Signal Processing',4,'Open','Elective','PG'),('ASE','Advanced Software Engineering',4,'Program','Elective','CSE'),('BC','Broadband Communication',4,'Program','Elective','ECE'),('BME','Bio-Medical Engineering',4,'Science','Elective','CSE,ECE,CCE'),('BSSS','Business Skills and Soft Skills',4,'HSS','Elective','ECE,CCE,CSE'),('CN','Computer Networks',4,'Open','Compulsory','ECE,CSE,CCE'),('COA','Computer Organisation and Architecture',4,'Open','Compulsory','CCE,CSE'),('CoT','Coding Theory',4,'Program','Elective','ECE,CCE'),('CP','Computer Programming',5,'Open','Compulsory','CCE,CSE,ECE'),('CT','Communication Theory',4,'Program','Elective','ECE.CCE'),('DAA','Design and Analysis of Algorithm',4,'Open','Compulsary','CSE'),('DBMS','Database Management systems',4,'Open','Compulsary','CSE'),('DC','Digital Communication',4,'Open','Compulsary','CCE,ECE'),('DCS','Digital Circuits and Systems',4,'Open','Compulsary','CCE,CSE,ECE'),('DMS','Discrete Mathematics',4,'Program','Compulsary','CSE'),('DSA','Data Structures',4,'Open','Compulsary','CCE,CSE'),('DSP','Digital Signal Processing',4,'Open','Compulsary','CCE,ECE'),('DWDM','Data Warehousing and Data Mining',4,'Program','Elective','CSE'),('ECEIII','Electronics III Lab',2,'Open','Compulsary','ECE'),('ECELabI','Electronics Lab',2,'Open','Compulsary','ECE,CCE,CSE'),('EE','Environment and Ecology',4,'Open','Compulsary','CSE,ECE,CCE'),('EEM','Engineering and Electromagnetics',4,'Open','Compulsary','ECE,CCE'),('EI','ElectronicsI',5,'Open','Compulsary','CCE,CSE,ECE'),('EII','Electronics II',4,'Open','Compulsary','CSE,ECE,CCE'),('Eng','English',5,'Open','Compulsary','CCE,CSE,ECE'),('French','French',4,'HSS','Elective','CSE,ECE,CCE'),('HV','Human Values and Professional Ethics',4,'HSS','Elective','CSE,ECE,CCE'),('ITW','IT Workshop',4,'Open','Compulsary','CSE,ECE,CCE'),('LA','Linear Algebra',4,'Science','Elective','ECE,CCE,CSE'),('MC','Mobile communications',4,'Open','Compulsary','ECE,CCE'),('MCA','Microwave Circuits and Antennas',4,'Program','Elective','ECE.CCE'),('MDC','Modern Digital Communication',4,'Open','Elective','PG'),('MI','MathsI',4,'Open','Compulsary','CCE,CSE,ECE'),('MicroI','Microprocessors and Interfaces',4,'Open','Compulsary','ECE,CCE'),('MII','Mathematics II',4,'Open','Compulsary','ECE,CCE,CSE'),('MIII','Maths III',4,'Open','Compulsary','CCE,CSE,ECE'),('OBW','Organizational Behaviour at work',4,'HSS','Elective','ECE,CCE,CSE'),('Optics','Optics and Laser Communications',4,'Science','Elective','ECE,CCE,CSE'),('OS','Operating Systems',4,'Open','Compulsary','CSE'),('PA','Psychology and its Applications',4,'HSS','Elective','ECE,CCE,CSE'),('PhyLab','Physics Lab',2,'Open','Compulsary','CCE,CSE,ECE'),('PI','PhysicsI',4,'Open','Compulsary','CCE,CSE,ECE'),('PII','Physics II',4,'Open','Compulsary','ECE,CCE,CSE'),('POC','Principles of communications',4,'Open','Compulsary','ECE,CCE'),('PR','Pattern Recognition',4,'Program','Elective','CSE'),('PTSP','Probability Theory',4,'Open','Compulsary','ECE,CCE'),('SDC','Semiconductor Devices and Circuits',4,'Open','Compulsary','ECE'),('Signals','Signals,Systems and Control',4,'Open','Compulsary','ECE,CCE'),('SWE','Software Engineering',4,'Program','Elective','CSE'),('TCS','Topics in Computer Science',4,'Open','Elective','PG'),('TOC','Theory of Computation',4,'Open','Compulsory','CSE'),('VLSI','VLSI Fabrication Technology',4,'Program','Elective','ECE,CCE'),('Wavelets','Introduction to Wavelets',4,'Science','Elective','ECE,CCE,CSE'),('WMKM','Web Mining and Knowledge Management',4,'Program','Elective','CSE');
/*!40000 ALTER TABLE `course_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curriculum`
--

DROP TABLE IF EXISTS `curriculum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curriculum` (
  `Branch` varchar(20) NOT NULL,
  `Degree` varchar(20) NOT NULL,
  `HSS` varchar(20) NOT NULL,
  `Science` varchar(20) NOT NULL,
  `Program` varchar(20) NOT NULL,
  `Open` varchar(20) NOT NULL,
  `Compulsory` varchar(20) NOT NULL,
  `Year` varchar(20) NOT NULL,
  PRIMARY KEY (`Branch`,`Degree`,`Year`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curriculum`
--

LOCK TABLES `curriculum` WRITE;
/*!40000 ALTER TABLE `curriculum` DISABLE KEYS */;
INSERT INTO `curriculum` VALUES ('CCE','B.Tech','0','0','0','0','7','First'),('CCE','B.Tech','1','1','1','1','2','Fourth'),('CCE','B.Tech','1','0','0','0','5','Second'),('CCE','B.Tech','1','1','2','1','1','Third'),('CCE','B.Tech Hons.','1','1','1','1','1','Fourth'),('CCE','B.Tech Hons.','0','0','1','1','5','Second'),('CCE','B.Tech Hons.','0','2','1','1','1','Third'),('CSE','B.Tech','0','0','0','0','7','First'),('CSE','B.Tech','1','1','1','1','2','Fourth'),('CSE','B.Tech','1','0','0','0','5','Second'),('CSE','B.Tech','1','1','1','1','2','Third'),('CSE','B.Tech Hons.','1','1','1','1','1','Fourth'),('CSE','B.Tech Hons.','0','0','2','0','5','Second'),('CSE','B.Tech Hons.','1','1','1','2','1','Third'),('ECE','B.Tech','0','0','0','0','7','First'),('ECE','B.Tech','1','1','1','1','0','Fourth'),('ECE','B.Tech','1','0','1','0','4','Second'),('ECE','B.Tech','1','0','1','1','3','Third'),('ECE','B.Tech Hons.','1','1','1','1','1','Fourth'),('ECE','B.Tech Hons.','1','1','1','0','4','Second'),('ECE','B.Tech Hons.','0','2','1','1','1','Third');
/*!40000 ALTER TABLE `curriculum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_details`
--

DROP TABLE IF EXISTS `personal_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_details` (
  `Username` varchar(30) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Degree` varchar(45) NOT NULL,
  `Branch` varchar(45) NOT NULL,
  `CPI` varchar(45) DEFAULT NULL,
  `Year` varchar(45) NOT NULL DEFAULT 'First',
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_details`
--

LOCK TABLES `personal_details` WRITE;
/*!40000 ALTER TABLE `personal_details` DISABLE KEYS */;
INSERT INTO `personal_details` VALUES ('y08uc001','Shilpa Jain','B.Tech','CSE','7.8','Fourth'),('y08uc002','Neha Baheti','B.Tech Hons.','ECE','5.6','Fourth'),('y08uc003','Abha Pandey','B.Tech Hons.','CCE','9.8','Fourth'),('y08uc004','Ashish Kasera','B.Tech','CSE','9.0','Fourth'),('y08uc005','Ankit Garg','B.Tech','CSE','3.45','Fourth'),('y08uc006','Anu Gupta','B.Tech','ECE','9.1','Fourth'),('y08uc007','Binay','B.Tech','CSE','9.5','Fourth'),('y08uc008','Chaitanya','B.Tech Hons.','ECE','7.8','Fourth'),('y08uc009','Charmi','B.Tech','CSE','3.67','Fourth'),('y08uc010','Draco','B.Tech','ECE','7.0','Fourth'),('y08uc011','Gaurav','B.Tech Hons.','CSE','6.0','Fourth'),('y08uc012','Shubham','B.Tech','CSE','4.6','Fourth'),('y08uc013','Shantanu','B.Tech','CCE','6.0','Fourth'),('y08uc014','Vaidika','B.Tech','ECE','8.8','Fourth'),('y08uc015','Ravi Gorthi','B.Tech Hons.','CSE','9.0','Fourth'),('y09uc027','Anshul Jain','B.Tech','CSE','7.5','Third'),('y09uc084','Moulik Agarwal','B.Tech','ECE','8.4','Third'),('y09uc086','Mumal Seth','B.Tech','CSE','9.0','Third'),('y09uc150','Shreya Mundra','B.Tech','CSE','9.2','Third'),('y09uc157','Shubhi Gupta','B.Tech Hons.','ECE','8.9','Third'),('y09uc270','Shikha Sharma','B.Tech','CCE','6.8','Third'),('y09uc301','Karan Poddar','B.Tech','CSE','9.5','Third'),('y10uc100','Gunjan Jain','B.Tech Hons.','ECE','7.3','Second'),('y10uc103','Juhi Bhadviya','B.Tech','CSE','5.9','Second'),('y10uc121','Ayush Jain','B.Tech','CCE','6.0','Second'),('y10uc127','Vivek Sharma','B.Tech','ECE','7.6','Second'),('y10uc133','Nandita Jain','B.Tech Hons.','CSE','8.9','Second'),('y11uc004','Apurva Bangar','B.Tech    ','CSE','7.5','First'),('y11uc016','Medha Sharma','B.Tech Hons.','CSE','7.9','First'),('y11uc034','Apurva Jain','B.Tech','ECE','5.9','First'),('y11uc035','Medha Gupta','B.Tech Hons.','CCE','6.5','First'),('y11uc044','Shailja Khan','B.Tech','CCE','7.0','First'),('y11uc052','Shubha Mathur','B.Tech Hons.','ECE','5.6','First'),('y11uc054','Yasha Manocha','B.Tech','ECE','6.2','First');
/*!40000 ALTER TABLE `personal_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-04-24 20:42:52
