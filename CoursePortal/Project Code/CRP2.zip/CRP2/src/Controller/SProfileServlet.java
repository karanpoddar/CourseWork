package Controller;

import Model.RegisterService;
import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.User;

import Model.SProfileService;

@WebServlet("/Student")
public class SProfileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		User user = (User) request.getSession().getAttribute("user");
                SProfileService sprofileservice = new SProfileService();
                RequestDispatcher rd=null;
                if(user==null || (!user.getCategory().equals("Faculty") && !user.getCategory().equals("Dean") && !user.getCategory().equals("Student")))
                    response.sendRedirect("login");
                else
                {
                    if(user.getCategory().equals("Faculty") || user.getCategory().equals("Dean"))
                    {
                        if(request.getParameter("task").equals("View Profile"))
                        {
                            ResultSet rs = sprofileservice.getPreviousCourseList(request.getParameter("rollno"));
                            ResultSet rs1 = sprofileservice.getCurrentCourseList(request.getParameter("rollno"));
                            ResultSet rs2 = sprofileservice.getRegistrationDetails(request.getParameter("rollno"));
                            request.setAttribute("rsP", rs);
                            request.setAttribute("rsC", rs1);
                            request.setAttribute("rsR", rs2);
                            request.setAttribute("uname",request.getParameter("rollno"));
                            rd=request.getRequestDispatcher("SProfile.jsp");
                        }
                        else
                            response.sendRedirect("login");
                    }
                    else if(user.getCategory().equals("Student"))
                    {
                        if(request.getParameter("swapResponse")!=null)
                        {
                            if(request.getParameter("swapResponse").equals("Accept"))
                            {
                                RegisterService registerservice = new RegisterService();
                                sprofileservice.changeSwapStatus(request.getParameter("Student_ID1"), user.getUsername(), request.getParameter("Course_ID1"),  request.getParameter("Course_ID2"), "Accepted");
                                registerservice.swapCourses(request.getParameter("Student_ID1"), request.getParameter("Course_ID1"), user.getUsername(),  request.getParameter("Course_ID2"));
                                request.setAttribute("err","Swap Request Accepted");
                            }
                            else if(request.getParameter("swapResponse").equals("Reject"))
                            {
                                sprofileservice.changeSwapStatus(request.getParameter("Student_ID1"), user.getUsername(), request.getParameter("Course_ID1"),  request.getParameter("Course_ID2"), "Rejected");
                                request.setAttribute("err","Swap Request Rejected");
                            }
                            else
                                request.setAttribute("err","Invalid Choice");
                        }
                        ResultSet rs2 = sprofileservice.getRegistrationDetails(user.getUsername());
                        
                        ResultSet rsP = null;
                        rsP = sprofileservice.getPreviousCourseList(user.getUsername());

                        ResultSet application = null;
                        application = sprofileservice.getApplicationByMe(user.getUsername());

                        ResultSet swapByMe = null;
                        swapByMe = sprofileservice.getSwapRequestByMe(user.getUsername());

                        ResultSet swapForMe = null;
                        swapForMe = sprofileservice.getSwapRequestForMe(user.getUsername());

                        ResultSet rsC = null;
                        rsC = sprofileservice.getCurrentCourseList(user.getUsername());

                        request.setAttribute("rsP", rsP);
                        request.setAttribute("rsC", rsC);
                        request.setAttribute("rsR", rs2);
                        request.setAttribute("swapForMe", swapForMe);
                        request.setAttribute("swapByMe", swapByMe);
                        request.setAttribute("application", application);
                        rd=request.getRequestDispatcher("SProfile.jsp");
                    }
                    rd.forward(request, response);
            }
        }
}