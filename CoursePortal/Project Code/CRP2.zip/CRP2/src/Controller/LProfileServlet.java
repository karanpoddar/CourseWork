package Controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.LProfileService;

import dto.User;

@WebServlet("/LAS")
public class LProfileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
    	RequestDispatcher rd=null;
    	rd=request.getRequestDispatcher("LProfile.jsp");
    	rd.forward(request, response);
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		LProfileService lprofileservice = new LProfileService();
		User user = new User();
		user = (User) request.getSession().getAttribute("user");
		if(user==null || !user.getCategory().equals("LAS"))
			response.sendRedirect("login.jsp");
		else
		{
			RequestDispatcher rd;
			
			if(request.getParameter("form").equals("PR"))
			{
				String rollno = request.getParameter("rollno");
				
				int err = lprofileservice.approvePR(rollno);
				request.setAttribute("err", err);
				request.setAttribute("uname", rollno);
				rd=request.getRequestDispatcher("LProfile.jsp");
				rd.forward(request, response);
			}
			else
			{
				if(request.getParameter("form").equals("PRGSL"))
				{
					String rollno = request.getParameter("rollno");
					
					int err = lprofileservice.approvePR(rollno);
					request.setAttribute("err", err);
					request.setAttribute("uname", rollno);
				}
				ResultSet rs = lprofileservice.getStudentList();
				request.setAttribute("rs", rs);
				rd=request.getRequestDispatcher("LProfile2.jsp");
				rd.forward(request, response);
			}
		}
	}

}
