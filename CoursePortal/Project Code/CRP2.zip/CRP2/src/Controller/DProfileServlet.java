package Controller;

import Model.*;
import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.User;
import dto.studentDetails;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Random;

import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/Dean")
public class DProfileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
        User user = (User) request.getSession().getAttribute("user");
		RequestDispatcher rd;
		int flag1=0;
        if(user==null || !user.getCategory().equals("Dean"))
        {
        	flag1=1;
        	response.sendRedirect("login");
        }
        else if(request.getParameter("studentprofile")!=null)
		{
			SProfileService sprofileservice = new SProfileService();
                        ResultSet rs = sprofileservice.getPreviousCourseList(request.getParameter("rollno"));
                        ResultSet rs1 = sprofileservice.getCurrentCourseList(request.getParameter("rollno"));
                        ResultSet rsr = sprofileservice.getRegistrationDetails(request.getParameter("rollno"));
                        try 
                        {
                            if(!rs.isBeforeFirst() && !rs.isAfterLast() && !rs1.isBeforeFirst() && !rs1.isAfterLast() && !rsr.isBeforeFirst() && !rsr.isAfterLast())
                            {
                                request.setAttribute("err","No records found. Please check the Roll Number");
                            }
                            else
                            {
                            	flag1=1;
                                request.setAttribute("rsP", rs);
                                request.setAttribute("rsC", rs1);
                                request.setAttribute("rsR", rsr);
                                request.setAttribute("uname",request.getParameter("rollno"));

                                rd=request.getRequestDispatcher("SProfile.jsp");
                                rd.forward(request, response);	
                            }
                        } 
                        catch (SQLException ex) 
                        {
                            Logger.getLogger(DProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                }
		else
		{
			if(request.getParameter("course")!=null && request.getParameter("course").equals("Course Details"))
			{
				CourseService courseservice = new CourseService();
				InstiService instiservice = new InstiService();
				ResultSet rs = courseservice.getOfferedCourse();
				ResultSet rsu = instiservice.getUnofferedCourse();
				request.setAttribute("rs", rs);
				request.setAttribute("rsu", rsu);
				flag1=1;
				rd=request.getRequestDispatcher("AddCourse.jsp");
				rd.forward(request, response);		
			}
			else
			{	
				if(request.getParameter("timetable")!=null)
				{
					CourseService courseservice = new CourseService();
					ResultSet rs = courseservice.getOfferedCourse();
					request.setAttribute("rs", rs);
					rd=request.getRequestDispatcher("Timetable.jsp");
					flag1=1;
					rd.forward(request, response);	
					
				}
				else if(request.getParameter("delete")!=null)
				{
					DProfileService dprofileservice = new DProfileService();
					String[] appID= request.getParameterValues("applicationID");
					int flag=0;
					for(int i=0;appID!=null && i<appID.length;i++)
					{
						if(flag==0)
							flag=dprofileservice.deleteApplication(appID[i]);
						else
						{
							flag=flag+dprofileservice.deleteApplication(appID[i]);
						}
					}
					if(flag!=0)
						request.setAttribute("err", flag+" Pending Applications cannot be deleted");
				}
				else if(request.getParameter("deleteCourse")!=null && request.getParameter("deleteCourse").equals("unoffer"))
				{
					CourseService courseservice = new CourseService();
					String[] course = request.getParameterValues("deleteCourseList");
					
					int flag=0;
					for(int i=0;course!=null && i<course.length;i++)
					{
						if(flag==0)
							flag=courseservice.deleteCourse(course[i]);
						else
						{
							flag=flag+courseservice.deleteCourse(course[i]);
						}
					}
					if(flag!=0)
						request.setAttribute("err", flag+" Courses cannot be deleted");
					InstiService instiservice = new InstiService();
					ResultSet rs = courseservice.getOfferedCourse();
					ResultSet rsu = instiservice.getUnofferedCourse();
					request.setAttribute("rs", rs);
					request.setAttribute("rsu", rsu);
					flag1=1;
					rd=request.getRequestDispatcher("AddCourse.jsp");
					rd.forward(request, response);	
					
				}
				else if(request.getParameter("deleteCourse")!=null && request.getParameter("deleteCourse").equals("getStudentList"))
				{
					flag1=1;
					CourseService courseservice = new CourseService();
					ResultSet rs=null;
					String[] course = request.getParameterValues("deleteCourseList");
                    String deleteCourseList= null;
                    if(course!=null)
                    {
                        deleteCourseList = course[0];
                        rs=courseservice.getMultipleEnrolledStudentList(course);
                    }
                    request.setAttribute("rs", rs);
					rd=request.getRequestDispatcher("EnrolledStudentList.jsp");
					int i=1;
					while(course!=null && i<course.length)
					{
						deleteCourseList= deleteCourseList + ", "+course[i];
						i++;
					}
					request.setAttribute("courseId", deleteCourseList);
					rd.forward(request, response);
				}
				else if(request.getParameter("scheduleevents")!=null)
				{
					DProfileService dprofileservice = new DProfileService();
					ResultSet rs = dprofileservice.getEventSchedule();
					flag1=1;
					request.setAttribute("rs", rs);
					rd=request.getRequestDispatcher("EventSchedule.jsp");
					rd.forward(request, response);
				}
				else if(request.getParameter("offerCourse")!=null && !request.getParameter("offerCourse").equals(""))
				{
					flag1=1;
					String cid=request.getParameter("offerCourse");
					request.setAttribute("cid", cid);
                                        DProfileService dprofileservice = new DProfileService();
					ResultSet rs = dprofileservice.getFaculty();
					request.setAttribute("rs", rs);
					rd=request.getRequestDispatcher("EnterFaculty.jsp");
					rd.forward(request, response);
				}
				else if(request.getParameter("offer")!=null)
				{
					flag1=1;
					CourseService courseservice = new CourseService();
					courseservice.offerCourse(request.getParameter("offer"),request.getParameter("facId"));
					InstiService instiservice = new InstiService();
					ResultSet rs = courseservice.getOfferedCourse();
					ResultSet rsu = instiservice.getUnofferedCourse();
					request.setAttribute("rs", rs);
					request.setAttribute("rsu", rsu);
					rd=request.getRequestDispatcher("AddCourse.jsp");
					rd.forward(request, response);
				}
                                else if(request.getParameter("scheduleEvent")!=null)
				{
					DProfileService dprofileservice = new DProfileService();
					ResultSet rs = dprofileservice.getEventSchedule();
					try 
					{
						while(rs.next())
						{
							dprofileservice.updateEvent(rs.getString("Event"),request.getParameter(rs.getString("Event")+"Starts"),request.getParameter(rs.getString("Event")+"Ends"));
						}
					}
					catch (SQLException e) 
					{
						e.printStackTrace();
					}
				}
                                else if(request.getParameter("application")!=null)
                                {
                                    ResultSet rs;
                                    DProfileService dprofileservice = new DProfileService();
                                    rs=dprofileservice.getApplicationDetails(Integer.parseInt(request.getParameter("application")));
                                    request.setAttribute("app_content", rs);
                                    request.setAttribute("app", "view");
                                    try 
                                    {
                                        if(rs.next())
                                        {
                                            flag1=1;
                                            SProfileService sprofileservice = new SProfileService();
                                            ResultSet rsp = sprofileservice.getPreviousCourseList(rs.getString("Student_ID"));
                                            ResultSet rsc = sprofileservice.getCurrentCourseList(rs.getString("Student_ID"));
                                            ResultSet rsr = sprofileservice.getRegistrationDetails(rs.getString("Student_ID"));
                                            request.setAttribute("rsP", rsp);
                                            request.setAttribute("rsC", rsc);
                                            request.setAttribute("rsR", rsr);
                                            request.setAttribute("uname",rs.getString("Student_ID"));
                                            rs.beforeFirst();
                                            rd=request.getRequestDispatcher("SProfile.jsp");
                                            rd.forward(request, response);	
                                        }
                                        else
                                        {
                                            request.setAttribute("err","Wrong Application ID");
                                        }
                                    }
                                    catch (SQLException ex)
                                    {
                                        Logger.getLogger(DProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                else if(request.getParameter("appID")!=null)
                                {
                                    DProfileService dprofileservice = new DProfileService();
                                    if(request.getParameter("app_status").equals("Accept"))
                                    {
                                        dprofileservice.updateApplicationStatus(Integer.parseInt(request.getParameter("appID")),1,request.getParameter("studentID"));
                                    }
                                    else
                                    {
                                        dprofileservice.updateApplicationStatus(Integer.parseInt(request.getParameter("appID")),-1,request.getParameter("studentID"));
                                    }
                                }
                                else if(request.getParameter("reset")!=null && request.getParameter("reset").equals("Reset Course Registration Module"))
                                {
                                    CourseService courseservice = new CourseService();
                                    LoginService loginservice = new LoginService();
                                    RegisterService registerservice = new RegisterService();
                                    DProfileService dprofileservice = new DProfileService();
                                    ResultSet rs = courseservice.getOfferedCourse();
                                    try
                                    {
                                        while(rs.next())
                                        {
                                            courseservice.deleteCourse(rs.getString("Course_ID"));
                                        }
                                    }
                                    catch (SQLException ex) 
                                    {
                                        Logger.getLogger(DProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    courseservice.changeSemester();
                                    loginservice.resetPRStatus();
                                    registerservice.deleteSwapRequests();
                                    dprofileservice.deleteAllApplications();
                                }
                                else if(request.getParameter("allotment")!=null && request.getParameter("allotment").equals("Allocate Courses Now"))
                                {
                                    CourseService courseservice = new CourseService();
                                    InstiService instiservice = new InstiService();
                                    DProfileService dprofileservice = new DProfileService();
                                    int count=dprofileservice.getPendingApplications();
                                    if(count>0)
                                        request.setAttribute("err",count+" Pending Applications. Cannot Allot Courses");
                                    else
                                    {
                                        ResultSet rs = courseservice.getOfferedCourse();
                                        try 
                                        {
                                            rs.last();
                                            int size=rs.getRow();
                                            rs.beforeFirst();
                                            String[] course_id = new String[size];
                                            int[] max_seat =  new int[size];
                                            String[] Category =  new String[size];
                                            String[] Type =  new String[size];
                                            String[] Stream =  new String[size];
                                            int i=0;
                                            while(rs.next())
                                            {
                                                course_id[i]=rs.getString("Course_ID");
                                                max_seat[i]=rs.getInt("Max_Seats");
                                                Category[i]=rs.getString("Course_Category");
                                                Type[i]=rs.getString("Type");
                                                Stream[i]=rs.getString("Stream");
                                                i++;
                                            }

                                            for(int preference=1;preference<4;preference++)
                                            {
                                                for(i=0;i<size;i++)
                                                {
                                                    rs = dprofileservice.getRegisteredStudentWithPreference(course_id[i], preference);
                                                    rs.last();
                                                    int regCount=rs.getRow();
                                                    rs.beforeFirst();
                                                    if(regCount<=max_seat[i] || Type[i].equals("Compulsory"))
                                                    {
                                                        while(rs.next())
                                                        {
                                                            dprofileservice.assignCourse(course_id[i],rs.getString("Student_ID"));
                                                            max_seat[i]--;
                                                            regCount--;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        studentDetails[] student = new studentDetails[regCount];                                                    
                                                        Random chances = new Random();
                                                        int j=0;
                                                        float curChance;
                                                        while(rs.next() && j<regCount)
                                                        {
                                                            curChance=chances.nextInt(10)+1;
                                                            System.out.println(rs.getString("Student_ID"));
                                                            student[j] = new studentDetails();
                                                            student[j].setRollno(rs.getString("Student_ID"));
                                                            student[j].setYear(instiservice.getStudentYear(rs.getString("Student_ID")));
                                                            if(student[j].getYear().equals("Fourth"))
                                                            {
                                                                student[j].setPref(0.6*curChance);
                                                                j++;
                                                            }
                                                            else if(student[j].getYear().equals("Third"))
                                                            {
                                                                student[j].setPref(0.3*curChance);
                                                                j++;
                                                            }
                                                            else if(student[j].getYear().equals("Second"))
                                                            {
                                                                student[j].setPref(0.2*curChance);
                                                                j++;
                                                            }
                                                            else if(student[j].getYear().equals("Third"))
                                                            {
                                                                student[j].setPref(0.2*curChance);
                                                                j++;
                                                            }
                                                        }
                                                        Arrays.sort(student);
                                                        for(j=0;j<regCount;j++)
                                                        {
                                                            dprofileservice.assignCourse(course_id[i],student[j].getRollno());
                                                            max_seat[i]--;
                                                            System.out.println("Rollno: " + student[j].getRollno()+"Year: "+student[j].getYear() + "Pref: " + student[j].getPref());
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch (SQLException ex) 
                                        {
                                            Logger.getLogger(DProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                        request.setAttribute("err","Allocation Process Complete");
                                    }
                                }
			}
		}
		if(flag1==0)
		{
                    DProfileService dprofileservice = new DProfileService();
                    ResultSet rs = dprofileservice.getApplications();
                    request.setAttribute("rs", rs);
                    rd=request.getRequestDispatcher("DProfile.jsp");
                    rd.forward(request, response);
		}
	}
}