package Controller;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.User;

import Model.LoginService;
import Model.RegisterService;
import Model.SProfileService;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/login")
public class SessionServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
    	RequestDispatcher rd=null;
        LoginService loginservice = new LoginService();
    	ResultSet rs = loginservice.getEvent();
    	request.setAttribute("rs",rs);
    	rd=request.getRequestDispatcher("login.jsp");
    	rd.forward(request, response);

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
		String uname,passwd;
		RequestDispatcher rd=null;
		User newUser = (User) request.getSession().getAttribute("user");
		if(newUser==null)
		{
			uname=request.getParameter("uname");
			passwd=request.getParameter("passwd");
			
			if(uname == null || uname.trim()=="")
			{
				rd=request.getRequestDispatcher("login.jsp");
				request.setAttribute("err","Please Enter Username!");
				request.setAttribute("uname", uname);
				rd.forward(request, response);
			}
			else
			{
				if(passwd == null || passwd.trim()=="")
				{
					rd=request.getRequestDispatcher("login.jsp");
					request.setAttribute("uname", uname);
					request.setAttribute("err","Please Enter Password!");
					rd.forward(request, response);
				}
				else
				{
					LoginService loginService = new LoginService();
					User result = loginService.authenticate(uname,passwd);
			
					if(result.getUsername()==null)
					{
						LoginService loginservice = new LoginService();
				    	ResultSet rs = loginservice.getEvent();
				    	request.setAttribute("rs",rs);
				    	rd=request.getRequestDispatcher("login.jsp");
						request.setAttribute("uname", uname);
						request.setAttribute("err","Incorrect Username or Password!");
						rd.forward(request, response);
					}
					else
					{
                        SProfileService sprofileservice = new SProfileService();
                        ResultSet rs = sprofileservice.getRegistrationDetails(uname);
                        try 
                        {
                            if(rs.next())
                                result.setRegistrationType(rs.getString("Type"));
                        }
                        catch (SQLException ex) 
                        {
                            Logger.getLogger(SessionServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        RegisterService registerservice = new RegisterService();
                        registerservice.setCurrentEvent(result);
                                                
						rd=request.getRequestDispatcher("Profile");
						request.setAttribute("err","Login Successful!");
						request.getSession().setAttribute("user", result);
						rd.forward(request, response);
					}
				}
			}
		}
		else
		{
			response.sendRedirect("Profile");
		}
    }	

}
