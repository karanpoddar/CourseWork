package Controller;

import Model.*;
import dto.User;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		RequestDispatcher rd = null;
                ResultSet event;
                User user = (User) request.getSession().getAttribute("user");
                RegisterService registerservice = new RegisterService();
		if(user==null || !user.getCategory().equals("Student"))
			response.sendRedirect("login");
                else
                {
                    if(request.getParameter("Task")!=null)
                    {
                        if(request.getParameter("Task").equals("Swap Courses") && user.getEvent().equals("SwapDrop"))
                        {
                            request.setAttribute("swap", "selectStudent");
                            rd=request.getRequestDispatcher("SwapCourse.jsp");
                        }
                        else if((request.getParameter("Task").equals("Add/Drop Courses") || request.getParameter("Task").equals("Please Register"))&& user.getEvent().equals("Registration")  && user.getRegistrationType()==null )
                        {
                            rd=request.getRequestDispatcher("Register.jsp");
                        }
                        else if(request.getParameter("Task").equals("Drop Courses")&& user.getEvent().equals("SwapDrop"))
                        {
                            ResultSet rs;
                            SProfileService sprofileservice = new SProfileService();
                            rs = sprofileservice.getCurrentCourseList(user.getUsername());
                            request.setAttribute("rs", rs);
                            request.setAttribute("dropCourse", "selectCourse");
                            rd=request.getRequestDispatcher("DeleteCourse.jsp");
                        }
                        else
                            response.sendRedirect("Student");
                    }
                    else if(request.getParameter("Type")!=null && (user.getEvent().equals("Registration") || user.getEvent().equals("AddDrop")) && user.getRegistrationType()==null )
                    {
                        CourseService courseservice = new CourseService();
                        InstiService instiservice = new InstiService();
                        ResultSet curCourses = null;
                        if(request.getParameter("Type").equals("Normal Registration") || request.getParameter("Type").equals("Overload Registration"))
                        {
                            user.setRegistrationType(request.getParameter("Type"));
                            ResultSet compulsory = null;
                            ResultSet curriculum = null;
                            ResultSet rs = null;
                            curCourses = courseservice.getOfferedCourse();
                            rs = instiservice.getStudentDetails(user.getUsername());
                            try
                            {
                                if(rs!=null && rs.next())
                                {
                                    curriculum = instiservice.getCurriculum(rs.getString("Branch"),rs.getString("Degree"),rs.getString("Year"));
                                    compulsory = instiservice.getCompulsory(rs.getString("Branch"),rs.getString("Degree"),rs.getString("Year"));
                                }
                            }
                            catch (SQLException ex)
                            {
                                Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            request.setAttribute("compulsory",compulsory);
                            request.setAttribute("curCourses",curCourses);
                            request.setAttribute("curriculum",curriculum);
                            if(request.getParameter("Type").equals("Overload Registration"))
                                request.setAttribute("Type","Overload Registration");
                            else if(request.getParameter("Type").equals("Normal Registration"))
                                request.setAttribute("Type","Normal Registration");
                            rd=request.getRequestDispatcher("Register.jsp");
                        }
                        else if(request.getParameter("Type").equals("Special Registration"))
                        {
                            user.setRegistrationType(request.getParameter("Type"));
                            curCourses = courseservice.getOfferedCourse();
                            request.setAttribute("curCourses",curCourses);
                            request.setAttribute("Type","Special Registration");
                            rd=request.getRequestDispatcher("Register.jsp");
                        }
                        else
                            response.sendRedirect("Student");
                    }
                    else if(request.getParameter("swap")!=null && user.getEvent().equals("SwapDrop"))
                    {
                        if(request.getParameter("swap").equals("Enter"))
                        {
                            if(request.getParameter("rollno").trim().equals(""))
                            {
                                request.setAttribute("err","Please Enter a valid Roll Number");
                                request.setAttribute("swap", "selectStudent");
                                rd=request.getRequestDispatcher("SwapCourse.jsp");
                            }
                            else
                            {
                                SProfileService sprofileservice = new SProfileService();
                                ResultSet coursesMy ;
                                ResultSet coursesOther;
                                coursesMy=sprofileservice.getCurrentElectiveCourseList(user.getUsername());
                                coursesOther=sprofileservice.getCurrentElectiveCourseList(request.getParameter("rollno").toLowerCase());
                                request.setAttribute("swap", "selectCourses");
                                request.setAttribute("uname2", request.getParameter("rollno").toLowerCase());
                                request.setAttribute("coursesMy", coursesMy);
                                request.setAttribute("coursesOther", coursesOther);
                                rd=request.getRequestDispatcher("SwapCourse.jsp");
                            }
                        }
                        else if(request.getParameter("swap").equals("Selected Courses"))
                        {
                            if(request.getParameter("courseMy")!=null && request.getParameter("courseOther")!=null)
                            {
                                registerservice.sendSwapRequest(user.getUsername(),request.getParameter("courseMy").toString(),request.getParameter("uname2").toString(),request.getParameter("courseOther").toString());
                                request.setAttribute("err","Application Sent for Swap");
                                rd=request.getRequestDispatcher("Student");
                            }
                            else
                            {
                                request.setAttribute("err","You did not selected Courses. Please Retry");
                                request.setAttribute("swap", "selectStudent");
                                rd=request.getRequestDispatcher("SwapCourse.jsp");
                            }
                        }
                        else
                            response.sendRedirect("Student");
                    }
                    else if(request.getParameter("dropCourse")!=null && user.getEvent().equals("SwapDrop"))
                    {
                        if(request.getParameter("dropCourse").equals("courses"))
                        {
                            String[] courses=request.getParameterValues("courses");
                            for(int i=0;courses!=null && i<courses.length;i++)
                            {
                                registerservice.dropCourse(user.getUsername(), courses[i]);
                            }
                            request.setAttribute("err","Selected Courses Dropped");
                            rd=request.getRequestDispatcher("Student");
                        }
                        else
                            response.sendRedirect("Student");
                    }
                    else if(request.getParameter("Registration")!=null && user.getEvent().equals("Registration") && user.getRegistrationType()!=null)
                    {
                        SProfileService sprofileservice = new SProfileService();
                        ResultSet rs = sprofileservice.getRegistrationDetails(user.getUsername());
                        int regCheck=0;
                        if(rs!=null)
                        {
                            try 
                            {
                                rs.last();
                                regCheck=rs.getRow();
                            } 
                            catch (SQLException ex) 
                            {
                                Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                        if(request.getParameter("Registration").equals("Register") && regCheck==0)
                        {
                            InstiService instiservice = new InstiService();
                            String RegisType=user.getRegistrationType();
                            RegisType = (RegisType.split(" "))[0];
                            if(user.getRegistrationType().equals("Overload Registration") || user.getRegistrationType().equals("Special Registration"))
                            {
                                registerservice.sendApplication(user.getUsername(),request.getParameter("Application"),RegisType);
                            }
                            if(user.getRegistrationType().equals("Normal Registration") || user.getRegistrationType().equals("Overload Registration"))
                            {
                                rs = instiservice.getStudentDetails(user.getUsername());
                                try
                                {
                                    rs.next();
                                    int count=0;
                                    String[] type = {"Compulsory","Program","HSS","Open","Science"};
                                    ResultSet curriculum = instiservice.getCurriculum(rs.getString("Branch"),rs.getString("Degree"),rs.getString("Year"));
                                    curriculum.next();
                                    for(int k=0;k<5;k++)
                                    {
                                        count=Integer.parseInt(curriculum.getString(type[k]));
                                        for(int j=1;j<=count;j++)
                                        {
                                            String typecount;
                                            for(int i=1;i<4;i++)
                                            {
                                                typecount=type[k]+""+j+""+i;
                                                if(request.getParameter(typecount)!=null && !request.getParameter(typecount).equals("none"))
                                                {
                                                    registerservice.registerForCourse(user.getUsername(), request.getParameter(typecount), RegisType, i, type[k]+""+j);
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (SQLException ex)
                                {
                                    Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            if(user.getRegistrationType().equals("Overload Registration"))
                            {
                                for(int i=1;i<4;i++)
                                {
                                    String typecount="Overload"+""+i;
                                    if(request.getParameter(typecount)!=null && !request.getParameter(typecount).equals("none"))
                                    {
                                        registerservice.registerForCourse(user.getUsername(), request.getParameter(typecount), RegisType, i, "Overload");
                                    }
                                }
                            }
                            if(user.getRegistrationType().equals("Special Registration"))
                            {
                                for(int j=1;j<=7;j++)
                                {
                                    for(int i=1;i<4;i++)
                                    {
                                        String typecount="Special"+""+j+""+i;
                                        if(request.getParameter(typecount)!=null && !request.getParameter(typecount).equals("none"))
                                        {
                                            registerservice.registerForCourse(user.getUsername(), request.getParameter(typecount), RegisType, i, "Special"+""+j);
                                        }
                                    }
                                }
                            }
                            request.setAttribute("err","Registration Complete. Wait for Completion of Allotment Process");
                            rd=request.getRequestDispatcher("Student");
                        }
                        else
                            response.sendRedirect("Student");
                    }
                    else
                            response.sendRedirect("Student");
                    rd.forward(request, response);
                }
	}
}
