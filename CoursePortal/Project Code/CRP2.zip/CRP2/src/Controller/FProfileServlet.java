package Controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.User;

import Model.CourseService;
import Model.FProfileService;
import Model.SProfileService;

@WebServlet("/Faculty")
public class FProfileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		User user = (User) request.getSession().getAttribute("user");
		if(user==null || !user.getCategory().equals("Faculty"))
			response.sendRedirect("login");
		else
		{
			if(request.getParameter("task")==null)
			{
				FProfileService fprofileservice = new FProfileService();
				
				ResultSet rs = fprofileservice.viewProfile(user.getUsername());
				
				rd=request.getRequestDispatcher("FProfile.jsp");
				request.setAttribute("rs", rs);
				rd.forward(request, response);
			}
			else
			{
				if(request.getParameter("task").equals("Edit Course"))
				{
					CourseService courseservice = new CourseService();
					
					ResultSet rs = courseservice.getCourseDetails(request.getParameter("courseId"));
					ResultSet rs1 = courseservice.getOfferedCourse();
					
					rd=request.getRequestDispatcher("EditCourse.jsp");
					request.setAttribute("rs", rs);
					request.setAttribute("rs1", rs1);
					rd.forward(request, response);
				}
				if(request.getParameter("task").equals("Update"))
				{
					FProfileService fprofileservice = new FProfileService();
					CourseService courseservice = new CourseService();
					
					int i=0;
					String attribute = " ";
					String prerequisites="";
					String[] prereq=request.getParameterValues("prerequisites");
					for(i=0;i<prereq.length-1;i++)
						prerequisites=prerequisites+prereq[i]+", ";
					prerequisites=prerequisites+prereq[i];
					attribute=attribute+"Max_Seats='"+request.getParameter("seats")+"'"+", PreRequisites='"+prerequisites+"'"+", Course_Description='"+request.getParameter("description")+"'";					
					if(!courseservice.updateCourse(attribute,request.getParameter("courseId")))
						request.setAttribute("err", "ERROR! Cannot update.");
					
					ResultSet rs = fprofileservice.viewProfile(user.getUsername().toString());
					
					rd=request.getRequestDispatcher("FProfile.jsp");
					request.setAttribute("rs", rs);
					rd.forward(request, response);
				}
				if(request.getParameter("task").equals("Get Enrolled Student List"))
				{
					CourseService courseservice = new CourseService();
					
					ResultSet rs = courseservice.getEnrolledStudentList(request.getParameter("courseId"));
					
					request.setAttribute("rs", rs);
					rd=request.getRequestDispatcher("EnrolledStudentList.jsp");
					request.setAttribute("courseId", request.getParameter("courseId"));
					rd.forward(request, response);
				}
			}
		}
	}
}
