package dto;

public class studentDetails implements Comparable{
    private String rollno;
    private String year;
    private double pref;
    
    public double getPref() 
    {
        return pref;
    }
    public void setPref(double pref) 
    {
        this.pref = pref;
    }
    public String getRollno() 
    {
        return rollno;
    }
    public void setRollno(String rollno) 
    {
        this.rollno = rollno;
    }
    public String getYear() 
    {
        return year;
    }
    public void setYear(String year) 
    {
        this.year = year;
    }
    @Override
    public int compareTo(Object obj)
    {
        studentDetails tmp = (studentDetails)obj;
        if(this.pref < tmp.pref)
        {
            return 1;
        }
        else if(this.pref > tmp.pref)
        { 
            return -1;
        }
        return 0; 
    }
}
