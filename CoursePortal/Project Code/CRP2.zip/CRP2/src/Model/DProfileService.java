package Model;

import java.sql.Connection;
import java.sql.ResultSet;

public class DProfileService 
{
	Connection con=Model.DBConnection.getConnection();
	ResultSet rs=null;
	java.sql.Statement stmt; 
	
	public ResultSet getApplications() 
	{
		String sql="select * from application";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
        public int getPendingApplications() 
	{
		String sql="select * ,COUNT(Status) from application where Status=0";
                int count=0;
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
                        if(rs!=null && rs.next())
                        {
                            count = Integer.parseInt(rs.getString("COUNT(Status)"));
                        }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return count;
	}
        public ResultSet getApplicationDetails(int application)
        {
            String sql="select * from application where Application_ID="+application;
            try
            {
                stmt = con.createStatement();
                rs=stmt.executeQuery(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return rs;
        }
        public ResultSet getFaculty()
	{
		ResultSet rs=null;
		String sql = "select Username from login_details where Category = 'Faculty'";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
	public int deleteApplication(String appID)
	{
		String sql="delete from application where Application_ID='"+appID+"' and Status!=0";
		try
		{
			stmt = con.createStatement();
			if(stmt.executeUpdate(sql)==0)
				return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	public ResultSet getEventSchedule()
	{
		ResultSet rs=null;
		String sql = "select * from event_schedule";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
        public void updateEvent(String Event,String Start_Time, String End_Time)
	{
		String sql="update event_schedule set Start_Time='"+Start_Time+"', End_Time='"+End_Time+"' where Event='"+Event+"'";
		try
		{
			con.createStatement().executeUpdate(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
        public void deleteAllApplications()
	{
		String sql="delete from application";
		try
		{
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
        public ResultSet getRegisteredStudentWithPreference(String course,int preference)
        {
            ResultSet rs=null;
            String sql="select * from registration_details where Course_ID='"+course+"' and Preference="+preference;
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return rs;
        }
        public void assignCourse(String course,String student)
        {
            String sql="select Category from registration_details where Student_ID='"+student+"' and Course_ID='"+course+"'";
            System.out.println(sql);
            try
            {
               stmt = con.createStatement();
               rs=stmt.executeQuery(sql);
               if(rs!=null && rs.next())
               {
                   sql="delete from registration_details where Student_ID='"+student+"' and  Category='"+rs.getString("Category")+"'";
                   stmt.executeUpdate(sql);
               }
               sql="insert into student_details values('"+student+"','"+course+"','Current')";
               stmt.executeUpdate(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        public void updateApplicationStatus(int appID,int status,String studentID)
        {
            String sql="update application set Status="+status+" where Application_ID="+appID;
            try
            {
               stmt = con.createStatement();
               stmt.executeUpdate(sql);
               sql="delete from registration_details where Student_ID='"+studentID+"'";
               stmt.executeUpdate(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
}