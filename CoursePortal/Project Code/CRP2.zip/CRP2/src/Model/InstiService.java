package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InstiService 
{
    ResultSet rs=null;
    Connection con = Model.DBConnection.getInstiConnection();
    java.sql.Statement stmt;
    public ResultSet getUnofferedCourse()
    {
        Connection conModule = Model.DBConnection.getConnection();
        CourseService courseservice = new CourseService();
        ResultSet rs2 = courseservice.getOfferedCourse();
        String list = "''";
        try 
        {
            if(rs2.next())
                list="'" + rs2.getString("Course_ID") + "'";
            while(rs2.next())
            {
                list= list + ", '" + rs2.getString("Course_ID") + "'";
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(CourseService.class.getName()).log(Level.SEVERE, null, ex);
        }
        String sql="Select * from course_details where Course_ID not in ("+list+")";
        try 
        {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet getStudentDetails(String uname)
    {
        String sql="Select * from personal_details where Username='"+uname+"'";
        try 
        {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
    public String getStudentYear(String uname)
    {
        String year=null;
        String sql="Select Year from personal_details where Username='"+uname+"'";
        try 
        {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
            if(rs.next())
                year=rs.getString("Year");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return year;
    }
    public ResultSet getCurriculum(String branch,String degree,String year)
    {
        String sql="Select * from curriculum where Branch = '"+branch+"' and degree = '"+degree+"' and Year='"+year+"'";
        try 
        {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet getCompulsory(String branch,String degree,String year)
    {
        Connection conModule = Model.DBConnection.getConnection();
        CourseService courseservice = new CourseService();
        ResultSet rs2 = courseservice.getOfferedCourse();
        String list = "";
        try 
        {
            if(rs2.next())
                list="'" + rs2.getString("Course_ID") + "'";
            while(rs2.next())
            {
                list= list + ", '" + rs2.getString("Course_ID") + "'";
            }
            String sql="Select compulsory.Course_ID,course_details.Course_Name,course_details.Course_Category,course_details.Type from compulsory,course_details where compulsory.Branch = '"+branch+"' and compulsory.Degree = '"+degree+"' and compulsory.Year = '"+year+"' and compulsory.Course_ID IN ("+list+") and compulsory.Course_ID=course_details.Course_ID";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(CourseService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
}
