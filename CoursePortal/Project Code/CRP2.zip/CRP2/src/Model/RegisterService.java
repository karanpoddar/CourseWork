package Model;

import dto.User;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletRequest;

public class RegisterService {
    Connection con=Model.DBConnection.getConnection();
	java.sql.Statement stmt;
        public int swapCourses(String uname1,String course1, String uname2,String course2)
        {
            int rs=0;
            String sql1="update student_details set Course_ID='"+course2+"' where Student_ID='"+uname1+"' and Course_ID='"+course1+"'";
            String sql2="update student_details set Course_ID='"+course1+"' where Student_ID='"+uname2+"' and Course_ID='"+course2+"'";
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeUpdate(sql1);   
                if(rs==1)
                    rs = stmt.executeUpdate(sql2);
                else
                    return 0;
                if(rs==0)
                {
                    sql1="update student_details set Course_ID='"+course1+"' where Student_ID='"+uname1+"' and Course_ID='"+course2+"'";
                    rs = stmt.executeUpdate(sql1);
                    return 0;
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return rs;
        }
        public void dropCourse(String uname, String course)
        {
            String sql="delete from student_details  where Student_ID='"+uname+"' and Course_ID='"+course+"'";
            try
            {
                stmt = con.createStatement();
		stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return;
        }
        public void sendSwapRequest(String uname1,String course1, String uname2,String course2)
        {
            String sql="insert into swap_course (Student_ID1,Student_ID2,Course_ID1,Course_ID2,Status) values ('"+uname1+"','"+uname2+"','"+course1+"','"+course2+"','Pending')";
            try
            {
                stmt = con.createStatement();
		stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
        public void setCurrentEvent(User user)
        {
            ResultSet rs = null;
            String sql="select * from event_schedule where Start_Time < NOW() and End_Time > NOW()";
            try
            {
                stmt = con.createStatement();
		rs = stmt.executeQuery(sql);
                boolean b = rs.next();          
                if(b)
                {
                    user.setEvent(rs.getString("Event"));
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
        public void sendApplication(String uname,String application,String type)
        {
            String sql="insert into application(Student_ID,Application_Content,Type) values('"+uname+"','"+application+"','"+type+"')";
            try
            {
                stmt = con.createStatement();
		stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
        public void registerForCourse(String uname,String course,String type,int preference,String category)
        {
            String sql="insert into registration_details values('"+uname+"','"+course+"','"+type+"',"+preference+",'"+category+"')";
            try
            {
                stmt = con.createStatement();
		stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
        public void deleteSwapRequests()
        {
            String sql="delete from swap_course";
            try
            {
                stmt = con.createStatement();
		stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
}
