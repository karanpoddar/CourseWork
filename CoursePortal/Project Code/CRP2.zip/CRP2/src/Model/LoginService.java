package Model;
import java.sql.Connection;
import java.sql.ResultSet;

import dto.User;

public class LoginService 
{
    	Connection con=Model.DBConnection.getConnection();
        java.sql.Statement stmt;
	public User authenticate(String uname, String passwd) 
	{
		ResultSet rs=null; 
		String sql="select * from login_details where Username='"+uname+"'";
		User user = new User();
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
			boolean b = rs.next();
			if(b)
			{
				if(rs.getString(2).equals(passwd))
				{
					user.setUsername(uname);
					user.setPassword(passwd);
					user.setCategory(rs.getString(3));
					user.setPR(rs.getString(4));	
				}
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return user;
	}
        public void resetPRStatus()
        {
            String sql="update login_details set Physically_Registered='0' where Category='Student'";
            try
            {
                stmt = con.createStatement();
                stmt.executeUpdate(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        public ResultSet getEvent()
	{
		ResultSet rs=null;
		String sql = "select * from event_schedule";
		try
		{
			rs=con.createStatement().executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return rs;
	}
}
