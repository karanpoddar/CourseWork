package Model;

import java.sql.Connection;
import java.sql.ResultSet;

public class SProfileService 
{
	Connection con=Model.DBConnection.getConnection();
	java.sql.Statement stmt;
	public ResultSet getPreviousCourseList(String uname)
	{
		ResultSet rs = null; 
		String sql="select * from student_details where student_details.Student_ID='"+uname+"' and student_details.Semester='Previous'";
		try
		{
                        ResultSet rs1=null;
			stmt = con.createStatement();
			rs1 = stmt.executeQuery(sql);
                        String list = "''";
                        while(rs1.next())
                        {
                            list= list + ", '" + rs1.getString("Course_ID") + "'";
                        } 
                        sql="select * from course_details where Course_ID IN ("+list+")";
                        Connection conInsti=Model.DBConnection.getInstiConnection();
                        rs = conInsti.createStatement().executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;	
	}
	public ResultSet getCurrentCourseList(String uname)
	{
		ResultSet rs = null;
		String sql="select * from student_details,course_details where student_details.Student_ID='"+uname+"' and course_details.Course_ID=student_details.Course_ID  and student_details.Semester='Current'";
		try
		{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;
	}
        public ResultSet getCurrentElectiveCourseList(String uname)
	{
		ResultSet rs = null;
		String sql="select * from student_details,course_details where student_details.Student_ID='"+uname+"' and course_details.Course_ID=student_details.Course_ID  and student_details.Semester='Current' and course_details.Type='Elective'";
		try
		{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;
	}
        public ResultSet getApplicationByMe(String uname)
        {
            ResultSet rs = null;
            String sql="select * from application where Student_ID='"+uname+"'";
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return rs;
        }
        public ResultSet getSwapRequestForMe(String uname)
        {
            ResultSet rs=null;
            String sql="select * from swap_course where Student_ID2='"+uname+"'";
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return rs;
        }
        public ResultSet getSwapRequestByMe(String uname)
        {
            ResultSet rs=null;
            String sql="select * from swap_course where Student_ID1='"+uname+"'";
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return rs;
        }
        public void changeSwapStatus(String uname1,String uname2,String course1,String course2,String status)
        {
            String sql="update swap_course set Status='"+status+"' where Student_ID1='"+uname1+"' and Student_ID2='"+uname2+"' and Course_ID1='"+course1+"' and Course_ID2='"+course2+"' ";
            try
            {
                stmt = con.createStatement();
                stmt.executeUpdate(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
        }
        public ResultSet getRegistrationDetails(String uname)
        {
            String sql="select * from course_details,registration_details where Student_ID='"+uname+"' and course_details.Course_ID=registration_details.Course_ID ORDER BY Category";
            ResultSet rs=null;
            try
            {
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            return rs;
        }
}
