package Model;

import java.sql.Connection;
import java.sql.ResultSet;

public class FProfileService 
{
	ResultSet rs=null;
	Connection con=Model.DBConnection.getConnection();
	java.sql.Statement stmt; 
	public ResultSet viewProfile(String username)
	{
		
		String sql="Select * from course_details where Faculty_ID='"+ username +"'";
		try 
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;
	}
}
