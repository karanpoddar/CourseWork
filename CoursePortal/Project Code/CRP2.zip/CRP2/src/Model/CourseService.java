package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseService 
{
	ResultSet rs=null;
	Connection con=Model.DBConnection.getConnection();
	Connection con1=Model.DBConnection.getInstiConnection();
	java.sql.Statement stmt; 
	public ResultSet getCourseDetails(String courseId)
	{
		
		String sql="Select * from course_details where Course_ID='"+ courseId +"'";
		try 
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;
	}
	public ResultSet getOfferedCourse()
	{
		
		String sql="Select * from course_details";
		try 
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return rs;
	}

	public boolean updateCourse(String attribute, String courseId)
	{
		String sql="update course_details set"+attribute+" where Course_ID = '"+courseId+"'";
		try 
		{
			stmt = con.createStatement();
			if(stmt.executeUpdate(sql)==1)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public ResultSet getEnrolledStudentList(String courseId)
	{
		ResultSet rs=null;
		String sql = "select * from student_details where Course_ID='"+courseId+"' and Semester='Current'";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;	
	}
	public ResultSet getMultipleEnrolledStudentList(String[] course)
	{
		String sql="select * from student_details where Course_ID='"+course[0]+"'";
		ResultSet rs=null;
		try 
		{
			stmt = con.createStatement();
			String list = "";
			for(int i=1;i<course.length;i++)
			{
				rs=stmt.executeQuery(sql);
				list="''";
				while(rs.next())
				{
						list=list + ",'" + rs.getString("Student_ID")+"'";
				}
				sql="select * from student_details where Course_ID='"+course[i]+"' and Student_ID in ("+list+")";
			}
			rs=stmt.executeQuery(sql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return rs;
	}
	
	public int deleteCourse(String CourseID)
	{
		String sql="delete from course_details where Course_ID='"+CourseID+"'";
		String sql1="delete from registration_details where Course_ID='"+CourseID+"'";
		try
		{
			stmt = con.createStatement();
			if(stmt.executeUpdate(sql)==0 && stmt.executeUpdate(sql1)==0)
				return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	public void offerCourse(String cid, String facId)
	{
		String sql = "select * from course_details where Course_ID = '"+cid+"'";
		try
		{
			stmt = con1.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			sql="insert into course_details (Course_ID,Course_Name,Credits,Course_Category,Type,Stream,Faculty_ID) values('"+rs.getString("Course_ID")+"','"+rs.getString("Course_Name")+"',"+rs.getString("Credits")+",'"+rs.getString("Course_Category")+"','"+rs.getString("Type")+"','"+rs.getString("Stream")+"','"+facId+"')";
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
        public void changeSemester()
        {
            String sql = "update student_details set Semester = 'Previous' where Semester='Current'";
            try
            {
                stmt = con.createStatement();
                stmt.executeUpdate(sql);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
}
