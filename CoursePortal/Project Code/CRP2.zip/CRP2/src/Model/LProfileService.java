package Model;

import java.sql.Connection;
import java.sql.ResultSet;

public class LProfileService 
{
	Connection con=Model.DBConnection.getConnection();
	ResultSet rs=null;
	java.sql.Statement stmt; 
	
	public int approvePR(String uname) 
	{
		String sql="select * from login_details where Username='"+uname+"'";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);
			boolean b = rs.next();
			if(b)
			{
				if(rs.getString(4).equals("0"))
				{
					sql = "update login_details set Physically_Registered='1' where login_details.Username='" + uname +"'";
					con.prepareStatement(sql).executeUpdate();
					return 1;
				}
				else
				{
					return 2;
				}
			}
			else
				return 3;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	public ResultSet getStudentList()
	{
		String sql="select Username,Physically_Registered from login_details where Category='Student'";
		try
		{
			stmt = con.createStatement();
			rs=stmt.executeQuery(sql);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
}
